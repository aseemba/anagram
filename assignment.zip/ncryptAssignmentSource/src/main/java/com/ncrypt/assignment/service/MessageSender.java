package com.ncrypt.assignment.service;

import com.ncrypt.assignment.exception.CouldNotSendException;
import com.ncrypt.assignment.model.AnagramMessageData;

import java.util.logging.Level;
import java.util.logging.Logger;

public class MessageSender {

    private static final Logger LOGGER = Logger.getLogger(MessageSender.class.getName());

    private String destination;

    public MessageSender(String destination) {
        this.destination = destination;
    }

    public void send(Object msg) throws CouldNotSendException {
        if (!(msg instanceof AnagramMessageData) || destination == null || destination.trim() == "") {
            throw new CouldNotSendException("Invalid message or unspecified destination");
        }

        // send the message to destination
        LOGGER.log(Level.INFO, "Sending message to destination: " + destination);
    }
}
