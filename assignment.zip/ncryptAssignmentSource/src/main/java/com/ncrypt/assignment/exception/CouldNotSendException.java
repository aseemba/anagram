package com.ncrypt.assignment.exception;

public class CouldNotSendException extends Exception {
    public CouldNotSendException(String s) {
        super(s);
    }
}