package com.ncrypt.assignment.model;

public class AnagramMessageData implements Comparable<AnagramMessageData>{
    private String messageId;
    private boolean anagram;

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public boolean isAnagram() {
        return anagram;
    }

    public void setAnagram(boolean anagram) {
        this.anagram = anagram;
    }

    public AnagramMessageData withMessageId(String messageId) {
        this.messageId = messageId;
        return this;
    }

    public AnagramMessageData withAnagramFlag(boolean anagramFlag) {
        this.anagram = anagramFlag;
        return this;
    }

    @Override
    public String toString() {
        return "AnagramMessageData{" +
                "messageId='" + messageId + '\'' +
                ", anagram=" + anagram +
                '}';
    }

    @Override
    public int compareTo(AnagramMessageData other) {
        return this.getMessageId().compareTo(other.getMessageId());
    }
}
