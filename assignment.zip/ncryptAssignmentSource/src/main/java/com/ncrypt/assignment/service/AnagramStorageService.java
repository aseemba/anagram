package com.ncrypt.assignment.service;

import com.ncrypt.assignment.model.AnagramMessageData;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;

public class AnagramStorageService {
    private static final AnagramStorageService ANAGRAM_STORAGE_SERVICE = new AnagramStorageService();

    private BlockingQueue<AnagramMessageData> anagramMessageDataQueue;

    private AnagramStorageService() {
        this.anagramMessageDataQueue = new PriorityBlockingQueue<>(
                1024,
                (obj1, obj2) -> Integer.valueOf(obj2.getMessageId()).compareTo(Integer.valueOf(obj1.getMessageId())));
    }

    public static AnagramStorageService getInstance() {
        if(ANAGRAM_STORAGE_SERVICE != null) {
            return ANAGRAM_STORAGE_SERVICE;
        }
        return new AnagramStorageService();
    }

    public boolean store(AnagramMessageData messageData) {
        return anagramMessageDataQueue.offer(messageData);
    }

    public List<AnagramMessageData> retrieve() {
        List<AnagramMessageData> messageDataList = new ArrayList<>();
        anagramMessageDataQueue.drainTo(messageDataList);
        return messageDataList;
    }
}
