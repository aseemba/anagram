package com.ncrypt.assignment.service;

import com.ncrypt.assignment.model.AnagramMessage;

public interface AnagramMsgListener {
    void onAnagramMessage(AnagramMessage msg);
}
