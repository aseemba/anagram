package com.ncrypt.assignment.model;

public class AnagramMessage {
    private String string1;
    private String string2;
    private String id;
    public String getId() {
        return id;
    }
    public String getString1() {
        return string1;
    }
    public String getString2() {
        return string2;
    }

    public AnagramMessage withId(String id) {
        this.id = id;
        return this;
    }

    public AnagramMessage withString1(String string1) {
        this.string1 = string1;
        return this;
    }

    public AnagramMessage withString2(String string2) {
        this.string2 = string2;
        return this;
    }

    @Override
    public String toString() {
        return "AnagramMessage{" +
                "string1='" + string1 + '\'' +
                ", string2='" + string2 + '\'' +
                ", id='" + id + '\'' +
                '}';
    }
}
