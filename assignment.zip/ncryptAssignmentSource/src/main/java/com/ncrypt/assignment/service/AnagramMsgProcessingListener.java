package com.ncrypt.assignment.service;

import com.ncrypt.assignment.exception.CouldNotSendException;
import com.ncrypt.assignment.model.AnagramMessage;
import com.ncrypt.assignment.model.AnagramMessageData;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.ObjIntConsumer;
import java.util.function.Supplier;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AnagramMsgProcessingListener implements AnagramMsgListener {

    private static final Logger LOGGER = Logger.getLogger(AnagramMsgProcessingListener.class.getName());

    private MessageSender sender;

    @Override
    public void onAnagramMessage(AnagramMessage msg) {
        if (msg == null) {
            throw new IllegalArgumentException("Message should not be null");
        }

        AnagramMessageData anagramMessageData =
                new AnagramMessageData().withMessageId(msg.getId())
                        .withAnagramFlag(isAnagram(msg.getString1(), msg.getString2()));

        if(sendOrRetry(anagramMessageData)) {
            storeAnagramMessageData(anagramMessageData);
        }
    }

    boolean isAnagram(String str1, String str2) {
        if(str1 != null && str1.trim() != "" && str2 != null && str2.trim() != "") {
            Supplier<Long[]> start = () -> {
                Long[] a = new Long[1024];
                Arrays.fill(a, 0L);
                return a;
            };

            ObjIntConsumer<Long[]> accumulator = (map, number) -> map[number]++;
            BiConsumer<Long[], Long[]> combiner = (map1, map2) -> {};

            return Arrays.equals(str1.replaceAll("\\s", "").chars().collect(start, accumulator, combiner),
                    str2.replaceAll("\\s", "").chars().collect(start, accumulator, combiner));
        }
        return false;
    }

    boolean sendOrRetry(AnagramMessageData anagramMessageData) {
        if(anagramMessageData.isAnagram()) {
            sender = getMessageSender("http://10.130.83.91:8080");
        } else {
            sender = getMessageSender("http://10.130.83.90:8080");
        }

        boolean done = false;

        do {
            try {
                sender.send(anagramMessageData);
                done = true;
            } catch (CouldNotSendException e) {
                LOGGER.log(Level.INFO, "Failed to send the message, will retry in 3.5 seconds");
                try {
                    Thread.sleep(TimeUnit.SECONDS.toMillis(3500L));
                } catch (InterruptedException e1) {
                    LOGGER.log(Level.SEVERE, "Thread interrupted.");
                }
            }
        } while(!done);

        return done;
    }

    void storeAnagramMessageData(AnagramMessageData anagramMessageData) {
        if(AnagramStorageService.getInstance().store(anagramMessageData)) {
            LOGGER.log(Level.INFO, "Message data saved successfully.");
        }
    }

    MessageSender getMessageSender(String destination) {
        return new MessageSender(destination);
    }
}
