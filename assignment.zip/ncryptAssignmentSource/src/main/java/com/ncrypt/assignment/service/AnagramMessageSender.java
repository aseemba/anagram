package com.ncrypt.assignment.service;

import com.ncrypt.assignment.model.AnagramMessage;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class AnagramMessageSender {

    private static final AnagramMessageSender ANAGRAM_MESSAGE_SENDER = new AnagramMessageSender();
    private static final Logger LOGGER = Logger.getLogger(AnagramMessageSender.class.getName());

    private List<AnagramMsgListener> listeners = new ArrayList();

    private AnagramMessageSender() {

    }

    public static AnagramMessageSender getInstance() {
        if(ANAGRAM_MESSAGE_SENDER != null) {
            return ANAGRAM_MESSAGE_SENDER;
        }
        return new AnagramMessageSender();
    }

    public void addAnagramMsgListener(AnagramMsgListener listener) {
        listeners.add(listener);
    }

    public void sendMessage(AnagramMessage message) {
        LOGGER.info("Message received");
        notifyAnagramMsgAddedListeners(message);
    }

    protected void notifyAnagramMsgAddedListeners(AnagramMessage msg) {
        listeners.forEach(listener -> listener.onAnagramMessage(msg));
    }
}
