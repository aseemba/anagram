package com.ncrypt.assignment.main;

import com.ncrypt.assignment.model.AnagramMessage;
import com.ncrypt.assignment.model.AnagramMessageData;
import com.ncrypt.assignment.service.AnagramMessageSender;
import com.ncrypt.assignment.service.AnagramMsgProcessingListener;
import com.ncrypt.assignment.service.AnagramStorageService;

import java.util.List;
import java.util.Random;

public class AnagramMain {
    public static void main(String[] args) throws Exception {
        AnagramMessageSender messageSender = AnagramMessageSender.getInstance();
        messageSender.addAnagramMsgListener(new AnagramMsgProcessingListener());

        analyzeMessages(messageSender, 0, 100);

        retrieve();
    }

    private static void analyzeMessages(AnagramMessageSender messageSender, int lower, int upper) {
        for(int i=1; i<100; i++) {
            String iVal = String.valueOf(new Random().nextInt(upper-lower) + lower);
            messageSender.sendMessage(
                    new AnagramMessage().withId(iVal).withString1("DENS"+i%2).withString2("EN DS"+i%6)
            );
        }
    }

    private static void retrieve() {
        new Thread(() -> {
            boolean keepGoing = true;
            int count = 0;
            while(keepGoing && count < 3) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                List<AnagramMessageData> messageList = AnagramStorageService.getInstance().retrieve();
                messageList.stream().forEach(System.out::println);
                if (messageList.isEmpty()) {
                    count++;
                }
            }
        }).start();
    }
}
