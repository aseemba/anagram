package com.ncrypt.assignment.service;

import com.ncrypt.assignment.model.AnagramMessageData;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertFalse;

public class AnagramStorageServiceTest {

    @Test
    public void storeAndRetrieveIntegration() throws Exception {
        AnagramStorageService storageService = AnagramStorageService.getInstance();

        for(int i=0; i<10; i++) {
            storageService.store(new AnagramMessageData().withMessageId(String.valueOf(i)).withAnagramFlag(true));
        }

        List<AnagramMessageData> retrievedList = storageService.retrieve();
        assertFalse(retrievedList.isEmpty());
    }
}