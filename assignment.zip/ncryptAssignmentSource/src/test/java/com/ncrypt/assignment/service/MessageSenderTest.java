package com.ncrypt.assignment.service;

import com.ncrypt.assignment.exception.CouldNotSendException;
import com.ncrypt.assignment.model.AnagramMessageData;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class MessageSenderTest {

    private MessageSender messageSender;

    @After
    public void tearDown() throws Exception {
        messageSender = null;
    }

    @Test(expected = CouldNotSendException.class)
    public void send_InvalidMessageObject() throws Exception {
        messageSender = new MessageSender("destination");
        messageSender.send(new Object());
    }

    @Test(expected = CouldNotSendException.class)
    public void send_InvalidNullDestination() throws Exception {
        messageSender = new MessageSender(null);
        messageSender.send(new AnagramMessageData().withMessageId("1"));
    }

    @Test(expected = CouldNotSendException.class)
    public void send_InvalidEmptyDestination() throws Exception {
        messageSender = new MessageSender("");
        messageSender.send(new AnagramMessageData().withMessageId("1"));
    }

    @Test
    public void send() throws Exception {
        messageSender = new MessageSender("myDestination");
        messageSender.send(new AnagramMessageData().withMessageId("1"));
    }
}