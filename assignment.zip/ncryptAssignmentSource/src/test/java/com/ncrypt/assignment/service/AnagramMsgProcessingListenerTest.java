package com.ncrypt.assignment.service;

import com.ncrypt.assignment.model.AnagramMessage;
import com.ncrypt.assignment.model.AnagramMessageData;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class AnagramMsgProcessingListenerTest {

    private AnagramMsgProcessingListener listener;

    @Before
    public void setUp() throws Exception {
        listener = new AnagramMsgProcessingListener();
    }

    @After
    public void tearDown() throws Exception {
        listener = null;
    }

    @Test
    public void onAnagramMessage() throws Exception {
        listener = new AnagramMsgProcessingListener() {
            boolean sendOrRetry(AnagramMessageData anagramMessageData) {
                return true;
            }
        };

        listener.onAnagramMessage(new AnagramMessage().withId("1"));
    }

    @Test
    public void onAnagramMessage_NoStorage() throws Exception {
        listener = new AnagramMsgProcessingListener() {
          boolean sendOrRetry(AnagramMessageData anagramMessageData) {
              return false;
          }
        };

        listener.onAnagramMessage(new AnagramMessage().withId("1"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void onAnagramMessage_NullMessage() throws Exception {
        listener.onAnagramMessage(null);
    }

    @Test
    public void isAnagram_false() throws Exception {
        assertFalse(listener.isAnagram("DORMITORY", "CLEAN ROOM"));
    }

    @Test
    public void isAnagram_true() throws Exception {
        assertTrue(listener.isAnagram("DORMITORY", "DIRTY ROOM"));
    }

    @Test
    public void sendOrRetry_InvalidAnagram() throws Exception {
        assertTrue(listener.sendOrRetry(new AnagramMessageData().withMessageId("1").withAnagramFlag(false)));
    }

    @Test
    public void sendOrRetry_ValidAnagram() throws Exception {
        assertTrue(listener.sendOrRetry(new AnagramMessageData().withMessageId("1").withAnagramFlag(true)));
    }

    @Test
    public void storeAnagramMessageData() throws Exception {
        listener.storeAnagramMessageData(new AnagramMessageData().withMessageId("1").withAnagramFlag(true));
    }

    @Test
    public void sendOrRetry_Retry() throws Exception {
        listener = new AnagramMsgProcessingListener(){
            MessageSender getMessageSender(String destination) {
                return new MessageSender("");
            }
        };
        Thread testThread = new Thread(() -> listener.sendOrRetry(new AnagramMessageData()
                .withMessageId("1").withAnagramFlag(false)));
        testThread.start();

        testThread.sleep(10000);

        if(testThread.isAlive()) {
            testThread.interrupt();
        }
    }
}