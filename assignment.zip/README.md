﻿Programming assignment

There is a main class with can be run using the command:
`java -jar ncryptAssignment.jar`

The program analyzes 100 messages which may or may not be anagrams. Based on whether they are are not, the service routes them to the appropriate server (logs sending message).
The sent messages are stored in memory after being sent successfully.
The main method also retrieves the messages sent in descending order of their messageId and frees up the feed.

The source of the project for review can be found in `ncryptAssignmentSource` folder with the structure described below.

Project Structure:
```.
   ├── README.md
   ├── pom.xml
   └── src
       ├── main
       │   ├── java
       │   │   └── com
       │   │       └── ncrypt
       │   │           └── assignment
       │   │               ├── exception
       │   │               │   └── CouldNotSendException.java
       │   │               ├── main
       │   │               │   └── AnagramMain.java
       │   │               ├── model
       │   │               │   ├── AnagramMessage.java
       │   │               │   └── AnagramMessageData.java
       │   │               └── service
       │   │                   ├── AnagramMessageSender.java
       │   │                   ├── AnagramMsgListener.java
       │   │                   ├── AnagramMsgProcessingListener.java
       │   │                   ├── AnagramStorageService.java
       │   │                   └── MessageSender.java
       │   └── resources
       └── test
           └── java
               └── com
                   └── ncrypt
                       └── assignment
                           └── service
                               ├── AnagramMsgProcessingListenerTest.java
                               ├── AnagramStorageServiceTest.java
                               └── MessageSenderTest.java```
